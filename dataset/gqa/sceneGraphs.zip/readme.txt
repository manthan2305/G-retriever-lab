Scene graphs for the GQA dataset, for train and valiadation sets. 
Each image is associated with a scene graph the provides information about the objects, attributes and relations in the image.
Please visit gqadataset.org for all information about the dataset, including examples, visualizations, paper and slides. 
